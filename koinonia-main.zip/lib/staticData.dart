class StaticData {
  static String imagepath = 'lib/assets/images/';
}
