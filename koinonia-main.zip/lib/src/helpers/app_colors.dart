
import 'dart:ui';

class AppColors{
  static const Color DARK_ORANGE =  Color(0xFFF15C00);
}