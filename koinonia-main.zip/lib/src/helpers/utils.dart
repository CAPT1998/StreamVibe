
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Utils{
static final GlobalKey<RefreshIndicatorState> singlePlaylistRefreshIndicatorKey =
GlobalKey<RefreshIndicatorState>();

static final GlobalKey<RefreshIndicatorState> allPlayListRefreshIndicatorKey =
GlobalKey<RefreshIndicatorState>();

static final GlobalKey<RefreshIndicatorState> homepagePlaylistRefreshIndicatorKey =
GlobalKey<RefreshIndicatorState>();

}